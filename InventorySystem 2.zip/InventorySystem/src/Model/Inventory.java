package Model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;

public class Inventory {
    private static ObservableList<Part> allParts = FXCollections.observableArrayList();
    private static ObservableList<Product> allProducts = FXCollections.observableArrayList();

    public static void addPart(Part newPart){
        allParts.add(newPart);
    }
    public static void addProduct(Product newProduct){
        allProducts.add(newProduct);
    }
    public static Part lookupPart(int partId){
        for(int i = 0; i < allParts.size(); i++){
            if(allParts.get(i).getId() == partId){
                return allParts.get(i);
            }
        }
        Alert notFound = new Alert(Alert.AlertType.ERROR);
        notFound.setTitle("ERROR!");
        notFound.setHeaderText("Not found!");
        notFound.setContentText("No part found!");
        notFound.showAndWait();
        return null;
    }
    public static Product lookupProduct(int productId){
        for(int i = 0; i < allProducts.size(); i++){
            if(allProducts.get(i).getId() == productId){
                return allProducts.get(i);
            }
        }
        Alert notFound = new Alert(Alert.AlertType.ERROR);
        notFound.setTitle("ERROR!");
        notFound.setHeaderText("Not found!");
        notFound.setContentText("No product found!");
        notFound.showAndWait();
        return null;
    }
    public static ObservableList<Part> lookupPart(String partName){
        ObservableList<Part> returnedParts = FXCollections.observableArrayList();

        for(Part part: allParts){
            if(part.getName().contains(partName)){
                returnedParts.add(part);
            }
        }

        if(returnedParts.isEmpty()){
            Alert notFound = new Alert(Alert.AlertType.ERROR);
            notFound.setTitle("ERROR!");
            notFound.setHeaderText("Not found!");
            notFound.setContentText("No part found!");
            notFound.showAndWait();
            return null;
        }
        return returnedParts;
    }
    public static ObservableList<Product> lookupProduct(String productName){
        if(allProducts.isEmpty()){
            return null;
        }

        ObservableList<Product> returnedProducts = FXCollections.observableArrayList();
        for(Product product: allProducts){
            if(product.getName().contains(productName)){
                returnedProducts.add(product);
            }
        }
        if(returnedProducts.isEmpty()){
            Alert notFound = new Alert(Alert.AlertType.ERROR);
            notFound.setTitle("ERROR!");
            notFound.setHeaderText("Not found!");
            notFound.setContentText("No product found!");
            notFound.showAndWait();
        }
        return returnedProducts;
    }

    public static void updatePart(int index, Part selectedPart){
        allParts.set(index, selectedPart);
    }

    public static void updateProduct(int index, Product newProduct){
        allProducts.set(index, newProduct);
    }

    public static boolean deletePart(Part selectedPart){
        allParts.remove(selectedPart);
        return true;
    }

    public static boolean deleteProduct(Product selectedProduct){

        allProducts.remove(selectedProduct);
        return true;
    }

    public static ObservableList<Part> getAllParts(){
        return allParts;
    }

    public static ObservableList<Product> getAllProducts(){
        return allProducts;
    }

    public static int getLastPartId(){
        int maxId = 0;
        for(Part part: allParts){
            if(part.getId() > maxId){
                maxId = part.getId();
            }
        }
        return maxId;
    }

    public static int getLastProductId(){
        int maxId = 0;
        for(Product product: allProducts){
            if(product.getId() > maxId){
                maxId = product.getId();
            }
        }
        return maxId;
    }
}
