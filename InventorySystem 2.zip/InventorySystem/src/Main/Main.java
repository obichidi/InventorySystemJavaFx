package Main;

import Controller.MainController;
import Model.*;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {

        Inventory inv = new Inventory();
        addTestDataToInventory(inv);

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/MainScreen.fxml"));
      Controller.MainController controller = new MainController(inv);
        loader.setController(controller);

        Parent root = loader.load();
        Scene mainScreenScene = new Scene(root);
        stage.setScene(mainScreenScene);


        stage.show();

    }

    public static void addTestDataToInventory(Inventory inv) {


        Part testPartOne = new InHouse(1, "Graphics card", 399.00, 6, 1, 10, 901);
        Part testPartTwo = new InHouse(2, "Memory chip", 100.00, 4, 1, 20, 302);
        Part testPartThree = new InHouse(3, "Fan", 99.00, 8, 1, 40, 703);
        inv.addPart(testPartOne);
        inv.addPart(testPartTwo);
        inv.addPart(testPartThree);


        Part testPartFour = new Outsourced(4, "Talon MotherBoard", 500.00, 3, 1, 20, "Talon");
        Part testPartFive = new Outsourced(5, "Falco Memory chip", 200.00, 4, 1, 15, "Falco");
        Part testPartSix = new Outsourced(6, "Falco Fan", 100.00, 2, 1, 10, "Falco");
        inv.addPart(testPartFour);
        inv.addPart(testPartFive);
        inv.addPart(testPartSix);


        Product productOne = new Product(1, "Bare Bones Pc", 500.00, 3, 1, 20);
        Product productTwo = new Product(2, "Hackintosh", 700.00, 4, 1, 15);
        Product productThree = new Product(3, "Rasberry Pi", 1000.00, 20, 1, 10);
        Product productFour = new Product(4, "Test Inventory", 100, 1, 15);


        productOne.addAssociatedPart(testPartOne);
        productOne.addAssociatedPart(testPartTwo);
        productOne.addAssociatedPart(testPartThree);

        productTwo.addAssociatedPart(testPartOne);
        productTwo.addAssociatedPart(testPartFive);
        productTwo.addAssociatedPart(testPartSix);

        productThree.addAssociatedPart(testPartFour);
        productThree.addAssociatedPart(testPartFive);
        productThree.addAssociatedPart(testPartSix);


        inv.addProduct(productOne);
        inv.addProduct(productTwo);
        inv.addProduct(productThree);
        inv.addProduct(productFour);
    }
}

