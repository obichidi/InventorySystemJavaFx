package Controller;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

import Controller.MainController;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import Model.InHouse;
import Model.Inventory;
import Model.Outsourced;
import Model.Part;


public class ModifyPartController implements Initializable {

    @FXML private RadioButton inHouseRadioButton;
    @FXML private RadioButton outsourcedRadioButton;
    @FXML private Label partSwappableLabel;
    @FXML private TextField partIdTextField;
    @FXML private TextField partNameTextField;
    @FXML private TextField partInvTextField;
    @FXML private TextField partPriceTextField;
    @FXML private TextField partMaxTextField;
    @FXML private TextField partSwappableTextField;
    @FXML private TextField partMinTextField;
    @FXML private Button partSaveButton;
    @FXML private Button partCancelButton;

    Inventory inv;
    Part partSelected;
    int errorCode = 0;
    boolean isError = false;


    public ModifyPartController(Inventory inv, Part partSelected) {
        this.inv = inv;
        this.partSelected = partSelected;
    }


    @Override
    public void initialize(URL url, ResourceBundle rb) {

        if (partSelected instanceof Outsourced) {


            Outsourced outsourced = (Outsourced) this.partSelected;
            this.outsourcedRadioButton.setSelected(true);
            this.partIdTextField.setText(String.valueOf(outsourced.getId()));
            this.partNameTextField.setText(outsourced.getName());
            this.partInvTextField.setText(String.valueOf(outsourced.getStock()));
            this.partPriceTextField.setText(String.valueOf(outsourced.getPrice()));
            this.partMaxTextField.setText(String.valueOf(outsourced.getMax()));
            this.partMinTextField.setText(String.valueOf(outsourced.getMin()));
            this.partSwappableLabel.setText("Company Name");
            this.partSwappableTextField.setText(outsourced.getCompanyName());

        }


        if (partSelected instanceof InHouse) {
            InHouse inHouse = (InHouse) this.partSelected;
            this.inHouseRadioButton.setSelected(true);
            this.partIdTextField.setText(String.valueOf(inHouse.getId()));
            this.partNameTextField.setText(inHouse.getName());
            this.partInvTextField.setText(String.valueOf(inHouse.getStock()));
            this.partPriceTextField.setText(String.valueOf(inHouse.getPrice()));
            this.partMaxTextField.setText(String.valueOf(inHouse.getMax()));
            this.partMinTextField.setText(String.valueOf(inHouse.getMin()));
            this.partSwappableLabel.setText("Machine ID");
            this.partSwappableTextField.setText(String.valueOf(inHouse.getMachineId()));
        }
    }


    @FXML
    public void inHouseRadioButtonSelected(ActionEvent event) {
        outsourcedRadioButton.setSelected(false);
        partSwappableLabel.setText("Machine ID");
    }


    @FXML
    public void outsourcedRadioButtonSelected(ActionEvent event) {
        inHouseRadioButton.setSelected(false);
        partSwappableLabel.setText("Company Name");
    }


    @FXML
    public void cancelButtonPushed(ActionEvent event) {
        try {

            Alert cancelAlert = new Alert(Alert.AlertType.CONFIRMATION);
            cancelAlert.setTitle("CANCEL");
            cancelAlert.setHeaderText("Are you sure you want to cancel?");
            cancelAlert.setContentText("Click 'OK' to confirm.");
            Optional<ButtonType> decision = cancelAlert.showAndWait();


            if (decision.get() == ButtonType.OK) {

                FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/MainScreen.fxml"));
                MainController controller = new MainController(inv);
                loader.setController(controller);


                Parent mainScreenParent = loader.load();
                Scene mainScreenScene = new Scene(mainScreenParent);


                Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
                window.setScene(mainScreenScene);
                window.show();
            } else {
                return;
            }
        } catch (IOException e) {

        }
    }


    @FXML
    public void saveButtonPushed(ActionEvent event) {
        try {

            this.errorCode = 0;
            errorCheck();
            showAlert(errorCode);

            if (errorCode == 0) {
                if (inHouseRadioButton.isSelected() && (partSelected instanceof Outsourced)) {
                    updateToInHouse();
                }


                if (inHouseRadioButton.isSelected() && (partSelected instanceof InHouse)) {
                    updateToInHouse();
                }


                if (outsourcedRadioButton.isSelected() && (partSelected instanceof InHouse)) {
                    updateToOutsourced();
                }


                if (outsourcedRadioButton.isSelected() && (partSelected instanceof Outsourced)) {
                    updateToOutsourced();
                }


                FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/MainScreen.fxml"));
                MainController controller = new MainController(inv);
                loader.setController(controller);


                Parent mainScreenParent = loader.load();
                Scene mainScreenScene = new Scene(mainScreenParent);


                Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
                window.setScene(mainScreenScene);
                window.show();
            }
        } catch (IOException e) {

        }
    }


    public void updateToInHouse() {
        inv.updatePart(
                partSelected.getId() - 1,
                new InHouse(
                        Integer.valueOf(partIdTextField.getText()),
                        partNameTextField.getText(),
                        Double.valueOf(partPriceTextField.getText()),
                        Integer.valueOf(partInvTextField.getText()),
                        Integer.valueOf(partMinTextField.getText()),
                        Integer.valueOf(partMaxTextField.getText()),
                        Integer.valueOf(partSwappableTextField.getText()))
        );
    }


    public void updateToOutsourced() {
        inv.updatePart(
                partSelected.getId() - 1,
                new Outsourced(
                        Integer.valueOf(partIdTextField.getText()),
                        partNameTextField.getText(),
                        Double.valueOf(partPriceTextField.getText()),
                        Integer.valueOf(partInvTextField.getText()),
                        Integer.valueOf(partMinTextField.getText()),
                        Integer.valueOf(partMaxTextField.getText()),
                        partSwappableTextField.getText())
        );
    }


    public void errorCheck() {


        if (inHouseRadioButton.isSelected() && partSwappableTextField.getText().matches("[a-zA-Z]+")) {
            isError = true;
            this.errorCode = 1;
            return;
        }


        if (outsourcedRadioButton.isSelected() && partSwappableTextField.getText().matches("^[0-9]*$")) {
            isError = true;
            this.errorCode = 2;
            return;
        }


        if (partNameTextField.getText().isEmpty() ||
                partInvTextField.getText().isEmpty() ||
                partPriceTextField.getText().isEmpty() ||
                partMaxTextField.getText().isEmpty() ||
                partMinTextField.getText().isEmpty() ||
                partSwappableTextField.getText().isEmpty()
        ) {
            isError = true;
            this.errorCode = 3;
            return;
        }


        if (Integer.valueOf(partInvTextField.getText()) < 0 ||
                Integer.valueOf(partMaxTextField.getText()) < 0 ||
                Integer.valueOf(partMinTextField.getText()) < 0) {
            isError = true;
            this.errorCode = 4;
            return;

        } else if (Integer.valueOf(partInvTextField.getText()) >
                Integer.valueOf(partMaxTextField.getText())) {
            isError = true;
            this.errorCode = 5;
            return;

        } else if (Integer.valueOf(partInvTextField.getText()) <
                Integer.valueOf(partMinTextField.getText())) {
            isError = true;
            this.errorCode = 6;
            return;

        } else if (Integer.valueOf(partMinTextField.getText()) >
                Integer.valueOf(partMaxTextField.getText())) {
            isError = true;
            this.errorCode = 7;
            return;
        }
    }


    public void showAlert(int errorNumber) {

        Alert error = new Alert(Alert.AlertType.ERROR);
        error.setTitle("ERROR");
        error.setHeaderText("CANNOT SAVE");

        switch (errorNumber) {
            case 0:
                return;
            case 1:
                error.setContentText("Machine ID must be a number!");
                break;

            case 2:
                error.setContentText("Company name must not include text, nut just numbers!");
                break;

            case 3:
                error.setContentText("All fields must have content!");
                break;

            case 4:
                error.setContentText("Number cannot be negative!");
                break;

            case 5:
                error.setContentText("Inventory cannot be greater than max field!");
                break;

            case 6:
                error.setContentText("Inventory cannot be less than min field!");
                break;

            case 7:
                error.setContentText("Min cannot be greater than max!");
                break;

            default:
                error.showAndWait();
                return;
        }

    }

    }
