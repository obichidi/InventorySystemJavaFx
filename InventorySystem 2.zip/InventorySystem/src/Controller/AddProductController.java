package Controller;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import Model.Inventory;
import Model.Part;
import Model.Product;
import javafx.stage.Stage;

public class AddProductController implements Initializable {



    @FXML private TextField productIdTextField;
    @FXML private TextField productNameTextField;
    @FXML private TextField productInvTextField;
    @FXML private TextField productPriceTextField;
    @FXML private TextField productMaxTextField;
    @FXML private TextField productMinTextField;
    @FXML private TextField productSearchTextField;
    @FXML private TableView<Part> addProductTopTableView;
    @FXML private TableColumn<Part,Integer > productIdTopColumn;
    @FXML private TableColumn<Part, String> productNameTopColumn;
    @FXML private TableColumn<Part, Integer> productInventoryTopColumn;
    @FXML private TableColumn<Part, Double> productPriceTopColumn;
    @FXML private Button productAddButton;
    @FXML private Button productRemoveButton;
    @FXML private Button productSaveButton;
    @FXML private Button productCancelButton;
    @FXML private TableView<Part> addProductBottomTableView;
    @FXML private TableColumn<Part, Integer> productIdBottomColumn;
    @FXML private TableColumn<Part, String> productNameBottomColumn;
    @FXML private TableColumn<Part, Integer> productInventoryBottomColumn;
    @FXML private TableColumn<Part, Double> productPriceBottomColumn;

    Inventory inv;
    Part partSelected;
    int errorNumber;
    boolean isError = false;
    Product newProduct;

    private ObservableList<Part> allParts = FXCollections.observableArrayList();
    private ObservableList<Part> associatedPartsList = FXCollections.observableArrayList();
    private ObservableList<Part> partsSelectedList = FXCollections.observableArrayList();
    private ObservableList<Product> allProducts = FXCollections.observableArrayList();

    public AddProductController(Inventory inv){
        this.inv = inv;
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        allProducts.setAll(Inventory.getAllProducts());
        getNextIdNumber();
        setAllPartsTable();
    }

    public void setAllPartsTable(){

        allParts.setAll(Inventory.getAllParts());
        addProductTopTableView.setItems(allParts);

        productIdTopColumn.setCellValueFactory(new PropertyValueFactory<Part, Integer>("id"));
        productInventoryTopColumn.setCellValueFactory(new PropertyValueFactory<Part, Integer>("stock"));
        productNameTopColumn.setCellValueFactory(new PropertyValueFactory<Part, String>("name"));
        productPriceTopColumn.setCellValueFactory(new PropertyValueFactory<Part, Double>("price"));
    }
    @FXML
    void addAssociatedPart(ActionEvent event) {
        this.errorNumber = 0;
        partSelected = addProductTopTableView.getSelectionModel().getSelectedItem();
        if(partSelected == null){
            Alert nullPart = new Alert(Alert.AlertType.ERROR);
            nullPart.setTitle("ERROR!");
            nullPart.setHeaderText("No part selected!");
            nullPart.setContentText("A part must be selected to add it!");
            nullPart.showAndWait();
            return;
        }

        if(errorNumber == 0){


            partsSelectedList.add(partSelected);
            associatedPartsList.setAll(partsSelectedList);
            addProductBottomTableView.setItems(associatedPartsList);

            allParts.remove(partSelected);
            addProductTopTableView.refresh();

            productIdBottomColumn.setCellValueFactory(new PropertyValueFactory<Part, Integer>("id"));
            productInventoryBottomColumn.setCellValueFactory(new PropertyValueFactory<Part, Integer>("stock"));
            productNameBottomColumn.setCellValueFactory(new PropertyValueFactory<Part, String>("name"));
            productPriceBottomColumn.setCellValueFactory(new PropertyValueFactory<Part, Double>("price"));
        }
    }
    @FXML
    void cancelButtonPushed(ActionEvent event) {

    }
    @FXML
    void removeAssociatedPart(ActionEvent event) {
        Alert removeAlert = new Alert(Alert.AlertType.CONFIRMATION);
        removeAlert.setTitle("REMOVE");
        removeAlert.setHeaderText("Are you sure you want to remove the associated part?");
        removeAlert.setContentText("Click 'OK' to confirm.");
        Optional<ButtonType> decision = removeAlert.showAndWait();


        if(decision.get() == ButtonType.OK){


            this.errorNumber = 0;
            partSelected = addProductBottomTableView.getSelectionModel().getSelectedItem();
           errorCheck();
            showAlert(errorNumber);

            if(errorNumber == 0){



                partsSelectedList.remove(partSelected);
                allParts.add(partSelected);

                addProductTopTableView.setItems(allParts);
                associatedPartsList.setAll(partsSelectedList);
                addProductBottomTableView.setItems(associatedPartsList);


                addProductTopTableView.refresh();
                addProductBottomTableView.refresh();

                productIdBottomColumn.setCellValueFactory(new PropertyValueFactory<Part, Integer>("id"));
                productInventoryBottomColumn.setCellValueFactory(new PropertyValueFactory<Part, Integer>("stock"));
                productNameBottomColumn.setCellValueFactory(new PropertyValueFactory<Part, String>("name"));
                productPriceBottomColumn.setCellValueFactory(new PropertyValueFactory<Part, Double>("price"));
            }
        }

    }
    @FXML
    void saveButtonPushed(ActionEvent event) {
        try{
            this.errorNumber = 0;
            errorCheck();
            showAlert(errorNumber);
            if(errorNumber == 0){
                newProduct = new Product(
                        Integer.valueOf(productIdTextField.getText()),
                        productNameTextField.getText(),
                        Double.valueOf(productPriceTextField.getText()),
                        Integer.valueOf(productInvTextField.getText()),
                        Integer.valueOf(productMinTextField.getText()),
                        Integer.valueOf(productMaxTextField.getText())

                );
                for(Part part: associatedPartsList){
                    newProduct.addAssociatedPart(part);
                }

                inv.addProduct(newProduct);



                FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/MainScreen.fxml"));
                MainController controller = new MainController(inv);
                loader.setController(controller);


                Parent mainScreenParent = loader.load();
                Scene mainScreenScene = new Scene(mainScreenParent);


                Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
                window.setScene(mainScreenScene);
                window.show();
            }
        }catch(IOException e){

        }
    }

    public void errorCheck() {

        if (partSelected == null) {
            this.errorNumber = 1;
            isError = true;
            return;
        }

        if (productNameTextField.getText().isEmpty() ||
                productInvTextField.getText().isEmpty() ||
                productPriceTextField.getText().isEmpty() ||
                productMaxTextField.getText().isEmpty() ||
                productMinTextField.getText().isEmpty()) {
            this.errorNumber = 2;
            isError = true;
            return;
        }

        if (associatedPartsList.isEmpty()) {
            this.errorNumber = 3;
            isError = true;
            return;
        }

        if (
                productInvTextField.getText().matches("[a-zA-Z]+") ||
                        productPriceTextField.getText().matches("[a-zA-Z]+") ||
                        productMaxTextField.getText().matches("[a-zA-Z]+") ||
                        productMinTextField.getText().matches("[a-zA-Z]+")) {

            isError = true;
            this.errorNumber = 5;
            return;
        }

        if (productNameTextField.getText().matches("^[0-9]*$")) {
            isError = true;
            this.errorNumber = 6;
            return;
        }

        if (Integer.valueOf(productInvTextField.getText()) < 0 ||
                Double.valueOf(productPriceTextField.getText()) < 0 ||
                Integer.valueOf(productMaxTextField.getText()) < 0 ||
                Integer.valueOf(productMinTextField.getText()) < 0) {
            this.errorNumber = 4;
            isError = true;
            return;
        }

        double sumOfPartsPrices = 0;
        for (Part part : associatedPartsList) {
            sumOfPartsPrices += part.getPrice();
        }
        if (Double.valueOf(productPriceTextField.getText()) < sumOfPartsPrices) {
            this.errorNumber = 7;
            isError = true;
            return;
        }
    }

    public void showAlert(int errorCode){
        Alert error = new Alert(Alert.AlertType.ERROR);
        error.setTitle("ERROR!");
        error.setHeaderText("Error adding product!");

        switch (errorNumber) {
            case 0:
                return;

            case 1:
                error.setHeaderText("Error adding associated part!");
                error.setContentText("A part must be selected or a part must be added!");
                break;

            case 2:
                error.setContentText("All fields must have content!");
                break;

            case 3:
                error.setContentText("A product must have at least one associated part!");
                break;

            case 4:
                error.setContentText("A product must have at least one associated part!");
                break;

            case 5:
                error.setContentText("Values of inv, price, max, and min must not contain letters");
                break;

            case 6:
                error.setContentText("Name of product can't contain numbers!");

            case 7:
                error.setContentText("Price of product cannot be less than sum of associated parts!");
                break;


            default:
                error.showAndWait();
                return;

    }

}

    public int getSizeOfAllParts(){
        return allProducts.size();
    }

    public int getSizeOfAllProducts(){
        return allProducts.size();
    }


    public void getNextIdNumber(){
        int size = getSizeOfAllProducts();

        if(size == 0){
            productIdTextField.setText("1");
        }else{
            for(int i = 0; i <=size; i++){
                if(i == 0){
                    continue;
                }
                if(Inventory.lookupProduct(i) == null){
                    productIdTextField.setText(String.valueOf(i));
                    break;
                }else if(Inventory.lookupProduct(i) != null){
                    if(i == size){

                        productIdTextField.setText(String.valueOf(Inventory.getLastProductId() + 1));
                    }
                    continue;
                }
            }
        }
    }
}
